<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.ride.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.rides.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="bus_id"><?php echo e(trans('cruds.ride.fields.bus')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('bus') ? 'is-invalid' : ''); ?>" name="bus_id" id="bus_id" required>
                    <?php $__currentLoopData = $buses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $bus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('bus_id') == $id ? 'selected' : ''); ?>><?php echo e($bus); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('bus')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('bus')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.ride.fields.bus_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="departure_place"><?php echo e(trans('cruds.ride.fields.departure_place')); ?></label>
                <input class="form-control <?php echo e($errors->has('departure_place') ? 'is-invalid' : ''); ?>" type="text" name="departure_place" id="departure_place" value="<?php echo e(old('departure_place', '')); ?>" required>
                <?php if($errors->has('departure_place')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('departure_place')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.ride.fields.departure_place_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="arrival_place"><?php echo e(trans('cruds.ride.fields.arrival_place')); ?></label>
                <input class="form-control <?php echo e($errors->has('arrival_place') ? 'is-invalid' : ''); ?>" type="text" name="arrival_place" id="arrival_place" value="<?php echo e(old('arrival_place', '')); ?>" required>
                <?php if($errors->has('arrival_place')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('arrival_place')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.ride.fields.arrival_place_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="departure_time"><?php echo e(trans('cruds.ride.fields.departure_time')); ?></label>
                <input class="form-control datetime <?php echo e($errors->has('departure_time') ? 'is-invalid' : ''); ?>" type="text" name="departure_time" id="departure_time" value="<?php echo e(old('departure_time')); ?>" required>
                <?php if($errors->has('departure_time')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('departure_time')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.ride.fields.departure_time_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="arrival_time"><?php echo e(trans('cruds.ride.fields.arrival_time')); ?></label>
                <input class="form-control datetime <?php echo e($errors->has('arrival_time') ? 'is-invalid' : ''); ?>" type="text" name="arrival_time" id="arrival_time" value="<?php echo e(old('arrival_time')); ?>" required>
                <?php if($errors->has('arrival_time')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('arrival_time')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.ride.fields.arrival_time_helper')); ?></span>
            </div>
            <div class="form-group">
                <div class="form-check <?php echo e($errors->has('is_booking_open') ? 'is-invalid' : ''); ?>">
                    <input class="form-check-input" type="checkbox" name="is_booking_open" id="is_booking_open" value="1" <?php echo e(old('is_booking_open', 0) == 1 || old('is_booking_open') === null ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="is_booking_open"><?php echo e(trans('cruds.ride.fields.is_booking_open')); ?></label>
                </div>
                <?php if($errors->has('is_booking_open')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('is_booking_open')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.ride.fields.is_booking_open_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SolutechBackend\resources\views/admin/rides/create.blade.php ENDPATH**/ ?>