<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tour extends Model
{
    //
    public $table = 'tours';

    // protected $dates = [
    //     'price',
    //     'arrival_time',
    //     'created_at',
    //     'updated_at',
    // ];

    protected $fillable = [
        'destination_id',
        'name',
        'description',
        'price',
        'arrival_time',
        'is_booking_open',
        'created_at',
        'updated_at',
    ];

}
