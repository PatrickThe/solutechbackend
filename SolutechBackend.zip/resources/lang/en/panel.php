<?php

return [
    'site_title' => 'Tour Bookings',
];
